/* Progamming Examples Chapter 4
    Programmmer : Bunga Aprillia
	Nim  		: 23343030
	Mata Kuliah : Struktur Data
    Soal  		: 10. Write a program to sort the names of students*/
    
#include <stdio.h>
#include <string.h>

int main() {
    char names[5][20], temp[20];
    int i, n, j;

    printf("\n =======================================");
    printf("\n Selamat datang dalam program");
    printf("\n Membaca sebuah string");
    printf("\n Bunga Aprillia (23343030)");
    printf("\n =======================================\n");

    printf("\n Enter the number of students (max 5): ");
    scanf("%d", &n);

    while (getchar() != '\n');

    for (i = 0; i < n; i++) {
        printf("\n Enter the name of student %d: ", i + 1);
        fgets(names[i], sizeof(names[i]), stdin);
        
        names[i][strcspn(names[i], "\n")] = '\0';
    }

    for (i = 0; i < n; i++) {
        for (j = 0; j < n - i - 1; j++) {
            if (strcmp(names[j], names[j + 1]) > 0) {
                strcpy(temp, names[j]);
                strcpy(names[j], names[j + 1]);
                strcpy(names[j + 1], temp);
            }
        }
    }

    printf("\n Names of the students in alphabetical order are:\n");
    for (i = 0; i < n; i++)
        printf("%s\n", names[i]);

    return 0;
}
