/* Progamming Examples Chapter 4
    Programmmer : Bunga Aprillia
	Nim  		: 23343030
	Mata Kuliah : Struktur Data
    Soal  		: 12. Write a program to find whether a string is a palindrome or not*/
    
#include <stdio.h>

int main(){
	char str[100];
	int i = 0, j, length = 0;
	
	printf("\n =======================================");
    printf("\n Selamat datang dalam program");
    printf("\n Membaca sebuah string");
    printf("\n Bunga Aprillia (23343030)");
    printf("\n =======================================\n");
    
	printf("\n Enter the string : ");
	gets(str);
	while(str[i] != '\0')
	{
		length++ ;
		i++ ;
	}
	i=0;
	j = length - 1;
	while(i <= length/2)
	{
		if(str[i] == str[j])
		{
			i++;
			j--;
		}
		else
			break;
	}
	if(i>=j)
		printf("\n PALINDROME");
	else
		printf("\n NOT A PALINDROME");
	return 0;
}

