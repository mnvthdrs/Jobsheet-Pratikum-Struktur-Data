/* Progamming Examples Chapter 4
    Programmmer : Bunga Aprillia
	Nim  		: 23343030
	Mata Kuliah : Struktur Data
    Soal  		: 14. Write a program to concatenate two strings*/

#include <stdio.h>
#include <string.h>

int main() {
    char str1[100], str2[100], copy_str[200];
    char *pstr1, *pstr2, *pcopy_str;
    
    printf("\n =======================================");
    printf("\n Selamat datang dalam program");
    printf("\n Membaca sebuah string");
    printf("\n Bunga Aprillia (23343030)");
    printf("\n =======================================\n");

    pstr1 = str1;
    pstr2 = str2;
    pcopy_str = copy_str;
    
    printf("\n Enter the first string : ");
    fgets(str1, sizeof(str1), stdin);
    
    printf("\n Enter the second string : ");
    fgets(str2, sizeof(str2), stdin);

    while (*pstr1 != '\0') {
        *pcopy_str = *pstr1;
        pcopy_str++, pstr1++;
    }
 
    while (*pstr2 != '\0') {
        *pcopy_str = *pstr2;
        pcopy_str++, pstr2++;
    }
    *pcopy_str = '\0'; 

    printf("\n The concatenated text is : %s", copy_str);

    return 0;
}
