/* Progamming Examples Chapter 4
    Programmmer : Bunga Aprillia
	Nim  		: 23343030
	Mata Kuliah : Struktur Data
    Soal  		: 2. Write a program to convert the lower case characters of a string into upper case*/


#include <stdio.h>

int main(){
    char str[100], upper_str[100];
    int i = 0;

    printf("\n =======================================");
    printf("\n Selamat datang dalam program");
    printf("\n Membaca sebuah string");
    printf("\n Bunga Aprillia (23343030)");
    printf("\n =======================================\n");

    printf("\n Enter the string  : ");
    gets(str);

    while (str[i] != '\0') {
        if (str[i] >= 'a' && str[i] <= 'z')
            upper_str[i] = str[i] - 32;
        else
            upper_str[i] = str[i];
        i++;
    }

    upper_str[i] = '\0';

    printf("\n The string converted into upper case is  :  ");
    printf("%s", upper_str);

    return 0;
}
