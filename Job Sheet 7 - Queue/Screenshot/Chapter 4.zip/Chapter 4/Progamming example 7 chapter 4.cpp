/* Progamming Examples Chapter 4
    Programmmer : Bunga Aprillia
	Nim  		: 23343030
	Mata Kuliah : Struktur Data
    Soal  		: 7. Write a program to insert a string in the main text*/
    
#include <stdio.h>
    int main () {
	char text[100], str[20], ins_text[100];
    int i=0,  j=0,  k=0, pos ;
                         
    printf("\n =======================================");
    printf("\n Selamat datang dalam program");
    printf("\n Membaca sebuah string");
    printf("\n Bunga Aprillia (23343030)");
    printf("\n =======================================\n");
    
	printf( "\n Enter the main text  :  ") ;
    gets(text) ;
    printf( "\n Enter the string to be inserted  :  ") ;
    gets(str) ;
    printf( "\n Enter the position at which the string has to be inserted: ") ;
    scanf( "%d",  &pos) ;
    
	while(text [i] != '\0' ){
        if(i==pos){
    		while(str[k] != '\0' ){
				ins_text[j] = str [k];
                j++;
                k++;
            }
    }
    else {
    	ins_text[j] = text[i] ; 
        j++;
    }
    i++;
    }
    ins_text[j] = '\0' ;
    printf( "\n The new string is : ") ;
    puts(ins_text) ;
 	
	 return 0;
}