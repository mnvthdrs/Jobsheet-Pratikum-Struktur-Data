/* Progamming Examples Chapter 4
    Programmmer : Bunga Aprillia
	Nim  		: 23343030
	Mata Kuliah : Struktur Data
    Soal  		: 13. Write a program to copy a string into another string*/

#include <stdio.h>

int main(){
	char str[100], copy_str[100];
	char *pstr, *pcopy_str;

	printf("\n =======================================");
    printf("\n Selamat datang dalam program");
    printf("\n Membaca sebuah string");
    printf("\n Bunga Aprillia (23343030)");
    printf("\n =======================================\n");
    
	pstr = str;
	pcopy_str = copy_str;
	printf("\n Enter the string : ");
	gets(str);
	while(*pstr != '\0')
	{
		*pcopy_str = *pstr;
		pstr++, *pcopy_str++;
	}
	*pcopy_str = '\0';
	printf("\n The copied text is : ");
	while(*pcopy_str != '\0')
	{
		printf("%c", *pcopy_str);
		pcopy_str++;
	}
	return 0;
}

