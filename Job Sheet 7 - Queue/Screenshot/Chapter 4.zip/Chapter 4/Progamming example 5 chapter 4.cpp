/* Progamming Examples Chapter 4
    Programmmer : Bunga Aprillia
	Nim  		: 23343030
	Mata Kuliah : Struktur Data
    Soal  		: 5. Write a program to reseverse a given string*/

#include <stdio.h>
#include <string.h>

int main() {
    char str[100], reverse_str[100], temp;
    int i = 0, j = 0;

    printf("\n =======================================");
    printf("\n Selamat datang dalam program");
    printf("\n Membaca sebuah string");
    printf("\n Bunga Aprillia (23343030)");
    printf("\n =======================================\n");

    printf("\n Enter the string : ");
    fgets(str, sizeof(str), stdin);

    j = strlen(str) - 1;

    while (i < j) {
        temp = str[j];
        str[j] = str[i];
        str[i] = temp;
        i++;
        j--;
    }

    printf("\n The reversed string is: ");
    printf("%s", str);

    return 0;
}
