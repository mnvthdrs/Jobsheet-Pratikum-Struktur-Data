/* Progamming Examples Chapter 4
    Programmmer : Bunga Aprillia
	Nim  		: 23343030
	Mata Kuliah : Struktur Data
    Soal  		: 3. Write a program to append a string to another string*/

 #include <stdio.h>

int main() {
    char Dest_Str[100], Source_Str[50];
    int i = 0, j = 0;

    printf("\n =======================================");
    printf("\n Selamat datang dalam program");
    printf("\n Membaca sebuah string");
    printf("\n Bunga Aprillia (23343030)");
    printf("\n =======================================\n");

    printf("\n Enter the source string  :   ");
    gets(Source_Str);
    printf("\n Enter the destination string  :   ");
    gets(Dest_Str);

    while (Dest_Str[i] != '\0')
        i++;

    while (Source_Str[j] != '\0') {
        Dest_Str[i] = Source_Str[j];
        i++;
        j++;
    }

    Dest_Str[i] = '\0';

    printf("\n After appending, the destination string is :  ");
    printf("%s", Dest_Str);

    return 0;
}
