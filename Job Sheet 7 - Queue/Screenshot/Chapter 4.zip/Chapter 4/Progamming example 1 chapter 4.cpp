/* Progamming Examples Chapter 4
    Programmmer : Bunga Aprillia
	Nim  		: 23343030
	Mata Kuliah : Struktur Data
    Soal  		: 1.Write a program to find the length of a string.*/

#include <stdio.h>

int main() {
    char str[100];
    int i = 0, length; // Ubah tipe data i menjadi int untuk menyimpan panjang string.
    
	printf("\n =======================================");
    printf("\n Selamat datang dalam program"	);
    printf("\n Membaca sebuah string");
    printf("\n Bunga Aprillia (23343030)"	);
    printf("\n =======================================");
    
    printf("\n");

    // clrscr(); // Dihapus karena fungsi clrscr() tidak digunakan.

    printf("\n Enter the string: ");
    gets(str); // Tambahkan titik koma (;) setelah gets(str).

    while (str[i] != '\0')
        i++;

    length = i;

    printf("\n The length of the string is: %d", length);

    // getch(); // Dihapus karena fungsi getch() tidak digunakan.

    return 0;
}
