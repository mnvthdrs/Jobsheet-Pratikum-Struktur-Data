/* Progamming Examples Chapter 3
    Programmmer : Bunga Aprillia
	Nim  		: 23343030
	Mata Kuliah : Struktur Data
    Soal  		: 15. Write a program to display an array of given numbers*/
    
#include <stdio.h>
int main()
{
	int arr[]={1,2,3,4,5,6,7,8,9};
	int *ptr1, *ptr2;
	
	printf("\n \t\t\t ==============================================");
    printf("\n \t\t\t 	Selamat datang dalam program");
    printf("\n \t\t\t Membaca & menampilkan angka menggunakan array");
    printf("\n \t\t\t 	Bunga Aprillia (23343030)");
    printf("\n \t\t\t ==============================================");

    printf("\n");
    
	ptr1 = arr;
	ptr2 = &arr[8];
	while(ptr1<=ptr2)
	{
		printf("%d", *ptr1);
		ptr1++;
	}
	return 0;
}
