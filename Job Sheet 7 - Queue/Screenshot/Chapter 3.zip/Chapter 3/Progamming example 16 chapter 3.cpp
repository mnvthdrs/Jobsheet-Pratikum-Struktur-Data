/* Progamming Examples Chapter 3
    Programmmer : Bunga Aprillia
	Nim  		: 23343030
	Mata Kuliah : Struktur Data
    Soal  		: 16. Write a program to print the elements of a 2D array*/
    
#include <stdio.h>
#include <conio.h>
int main()
{
	int arr[2][2] = {12, 34, 56,32};
	int i, j;
	
	printf("\n \t\t\t ==============================================");
    printf("\n \t\t\t 	Selamat datang dalam program");
    printf("\n \t\t\t Membaca & menampilkan angka menggunakan array");
    printf("\n \t\t\t 	Bunga Aprillia (23343030)");
    printf("\n \t\t\t ==============================================");

    printf("\n");
    
	for(i=0; i<2; i++)
	{
		printf("\n");
		for(j=0;j<2;j++)
			printf("%d\t", arr[i][j]);
	}
	return 0;
}
