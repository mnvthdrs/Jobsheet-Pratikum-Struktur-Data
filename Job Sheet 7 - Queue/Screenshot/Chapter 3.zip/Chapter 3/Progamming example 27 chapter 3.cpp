/* Progamming Examples Chapter 3
    Programmmer : Bunga Aprillia
	Nim  		: 23343030
	Mata Kuliah : Struktur Data
    Soal  		: 27. Write a program which illustrates the use of a pointer to a three-dimensional array*/
    
#include <stdio.h>

int main() {
    int i, j, k;
    int arr[2][2][2];
    int (*parr)[2][2] = arr;

    printf("\n ==============================================");
    printf("\n Selamat datang dalam program");
    printf("\n Membaca & menampilkan angka menggunakan array");
    printf("\n Bunga Aprillia (23343030)");
    printf("\n ==============================================");

    printf("\n");

    printf("\n Enter the elements of a 2 x 2 x 2 array:\n");
    for (i = 0; i < 2; i++) {
        for (j = 0; j < 2; j++) {
            for (k = 0; k < 2; k++)
                scanf("%d", &arr[i][j][k]);
        }
    }

    printf("\n The elements of the 2 x 2 x 2 array are:\n");
    for (i = 0; i < 2; i++) {
        for (j = 0; j < 2; j++) {
            for (k = 0; k < 2; k++)
                printf("%d ", *(*(*(parr + i) + j) + k));
        }
    }

    return 0;
}
