/* Progamming Examples Chapter 3
    Programmmer : Bunga Aprillia
	Nim  		: 23343030
	Mata Kuliah : Struktur Data
    Soal  		: 8. Write a program to insert a number in an array that is already sorted in ascending order*/
    
#include <stdio.h>

int main() {
    int i, n, j, num, arr[10];
    
    printf("\n \t\t\t ==============================================");
    printf("\n \t\t\t 	Selamat datang dalam program"	);
    printf("\n \t\t\t Membaca & menampilkan angka menggunakan array");
    printf("\n \t\t\t 	Bunga Aprillia (23343030)"	);
    printf("\n \t\t\t ==============================================");
    
    printf("\n");
    
    printf("\n Enter the number of elements in the array : ");
    scanf("%d", &n);
    for (i = 0; i < n; i++) {
        printf("\n arr[%d] = ", i);
        scanf("%d", &arr[i]);
    }
    printf("\n Enter the number to be inserted : ");
    scanf("%d", &num);
    for (i = 0; i < n; i++) {
        if (arr[i] > num) {
            for (j = n - 1; j >= i; j--)
                arr[j + 1] = arr[j];
            arr[i] = num;
            break;
        }
    }
    n = n + 1;
    printf("\n The array after insertion of %d is : ", num);
    for (i = 0; i < n; i++)
        printf("\n arr[%d] = %d", i, arr[i]);
    return 0;
}
