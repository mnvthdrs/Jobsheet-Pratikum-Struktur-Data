/* Progamming Examples Chapter 3
    Programmmer : Bunga Aprillia
	Nim  		: 23343030
	Mata Kuliah : Struktur Data
    Soal  		: 7. Write a program to insert a number at a given location in an array*/
    
#include <stdio.h>

int main() {
    int i, n, num, pos, arr[10];
    
    printf("\n \t\t\t ==============================================");
    printf("\n \t\t\t 	Selamat datang dalam program");
    printf("\n \t\t\t Membaca & menampilkan angka menggunakan array");
    printf("\n \t\t\t 	Bunga Aprillia (23343030)");
    printf("\n \t\t\t ==============================================");
    
    printf("\n");
    
    printf("\n Enter the number of elements in the array : ");
    scanf("%d", &n);
    for (i = 0; i < n; i++) {
        printf("\n arr[%d] = ", i);
        scanf("%d", &arr[i]);
    }
    printf("\n Enter the number to be inserted : ");
    scanf("%d", &num);
    printf("\n Enter the position at which the number has to be added :");
    scanf("%d", &pos);
    for (i = n - 1; i >= pos; i--)
        arr[i + 1] = arr[i];
    arr[pos] = num;
    n = n + 1;
    printf("\n The array after insertion of %d is : ", num);
    for (i = 0; i < n; i++)
        printf("\n arr[%d] = %d", i, arr[i]);
    return 0;
}
