/* Progamming Examples Chapter 3
    Programmmer : Bunga Aprillia
	Nim  		: 23343030
	Mata Kuliah : Struktur Data
    Soal  		: 9. Write a program to delete a number from a given location in an array.*/

#include <stdio.h>
#include <conio.h>

int main() {
    int i, n, pos, arr[10];
    
    printf("\n \t\t\t ==============================================");
    printf("\n \t\t\t 	Selamat datang dalam program");
    printf("\n \t\t\t Membaca & menampilkan angka menggunakan array");
    printf("\n \t\t\t 	Bunga Aprillia (23343030)");
    printf("\n \t\t\t ==============================================");
    
    printf("\n");
    
    //clrscr();
    printf("\n Enter the number of elements in the array : ");
    scanf("%d", &n);
    for (i = 0; i < n; i++) {
        printf("\n arr[%d] = ", i);
        scanf("%d", &arr[i]);
    }
    printf("\n Enter the position from which the number has to be deleted : ");
    scanf("%d", &pos);
    for (i = pos; i < n - 1; i++)
        arr[i] = arr[i + 1];
    n--;
    printf("\n The array after deletion is : ");
    for (i = 0; i < n; i++)
        printf("\n arr[%d] = %d", i, arr[i]);
    getch();
    return 0;
}
