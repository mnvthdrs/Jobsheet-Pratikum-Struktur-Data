/* Progamming Examples Chapter 3
    Programmmer : Bunga Aprillia
	Nim  		: 23343030
	Mata Kuliah : Struktur Data
    Soal  		: 20. Write a program to read and display a 3×3 matrix*/
    
#include <stdio.h>
//#include <conio.h>
int main()
{
	int i, j, mat[3][3];
	
	printf("\n \t\t\t ==============================================");
    printf("\n \t\t\t 	Selamat datang dalam program");
    printf("\n \t\t\t Membaca & menampilkan angka menggunakan array");
    printf("\n \t\t\t 	Bunga Aprillia (23343030)");
    printf("\n \t\t\t ==============================================");

    printf("\n");

	//clrscr();
	printf("\n Enter the elements of the matrix "); 
	for (i=0; i<3;i++){
		for(j=0;j<3;j++)
		{
			scanf("%d", &mat[i][j]);
		}
	}
	printf("\n The elements of the matrix are "); 
	for(i=0;i<3;i++)
	{
		printf("\n"); 
		for(j=0;j<3;j++)
			printf("\t%d",mat[i][j]);
	}

	return 0;
	}


