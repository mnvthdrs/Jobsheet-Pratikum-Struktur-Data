/* Progamming Examples Chapter 3
    Programmmer : Bunga Aprillia
	Nim  		: 23343030
	Mata Kuliah : Struktur Data
    Soal  		: 19. Write a program to read a 2D array marks which stores the marks of 
					five students in three subjects. Write a program to display the highest marks in each subject.*/

#include <stdio.h>

int main() {
    int marks[5][3], i, j, max_marks;

  	printf("\n \t\t\t ==============================================");
    printf("\n \t\t\t 	Selamat datang dalam program");
    printf("\n \t\t\t Membaca & menampilkan angka menggunakan array");
    printf("\n \t\t\t 	Bunga Aprillia (23343030)");
    printf("\n \t\t\t ==============================================");

    printf("\n");

    for (i = 0; i < 5; i++) {
        printf("\n Enter the marks obtained by student %d", i + 1);
        for (j = 0; j < 3; j++) {
            printf("\n marks[%d][%d] = ", i, j);
            scanf("%d", &marks[i][j]);
        }
    }

    for (j = 0; j < 3; j++) {
        max_marks = -999;
        for (i = 0; i < 5; i++) {
            if (marks[i][j] > max_marks)
                max_marks = marks[i][j];
        }
        printf("\n The highest marks obtained in the subject %d = %d", j + 1, max_marks);
    }

    return 0;
}
