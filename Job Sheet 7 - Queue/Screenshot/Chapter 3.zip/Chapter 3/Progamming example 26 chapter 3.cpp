/* Progamming Examples Chapter 3
    Programmmer : Bunga Aprillia
	Nim  		: 23343030
	Mata Kuliah : Struktur Data
    Soal  		: 26. Write a program to read and display a 2x2x2 array*/
    
#include <stdio.h>

int main()
{
	int array[2][2][2], i, j, k;
	
	printf("\n ==============================================");
    printf("\n Selamat datang dalam program");
    printf("\n Membaca & menampilkan angka menggunakan array");
    printf("\n Bunga Aprillia (23343030)");
    printf("\n ==============================================");

    printf("\n");
	//clrscr();
	printf("\n Enter the elements of the matrix");
	for(i=0;i<2;i++)
	{
		for(j=0;j<2;j++)
		{
			for(k=0;k<2;k++)
			{
				scanf("%d", &array[i][j][k]);
			}
		}
	}
	printf("\n The matrix is : ");
	for(i=0;i<2;i++)
	{
		printf("\n");
		for(j=0;j<2;j++)
		{
			printf ("\n");
			for(k=0;k<2;k++)
				printf("\t array([%d][%d][%d] = %d", i, j, k, array[i]
[j][k]);
		}
	}
	//getch();
	return 0;
}

