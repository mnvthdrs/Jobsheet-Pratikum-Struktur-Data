/* Progamming Examples Chapter 3
    Programmmer : Bunga Aprillia
	Nim  		: 23343030
	Mata Kuliah : Struktur Data
    Soal  		: 2. Write a proggram to find the mean of n numbers using arrays*/
    
#include <stdio.h>

int main(){
	int i, n, arr[20], sum =0;
	float mean = 0.00;
	
	printf("\n \t\t\t ==============================================");
    printf("\n \t\t\t 	Selamat datang dalam program"	);
    printf("\n \t\t\t Membaca & menampilkan angka menggunakan array");
    printf("\n \t\t\t 	Bunga Aprillia (23343030)"	);
    printf("\n \t\t\t ==============================================");
    
    printf("\n");

	printf("\n Enter the number of elements in the array : ");
	scanf("%d", &n);
	
	for(i=0;i<n;i++){
		printf("\n arr[%d] = ", i);
		scanf("%d",&arr[i]);
	}
	
	for(i=0;i<n;i++)
		sum += arr[i];
	
	mean = (float)sum/n;
	
	printf("\n The sum of the array elements = %d", sum);
	printf("\n The mean of the array elements = %.2f", mean);
	
	return 0;
}