/* Progamming Examples Chapter 3
    Programmmer : Bunga Aprillia
	Nim  		: 23343030
	Mata Kuliah : Struktur Data
    Soal  		: 25. Write a program to read and display a 3x3 matrix*/
    
#include <stdio.h>

void display(int (*)[3]);

int main() {
    int i, j, mat[3][3];

    printf("\n ==============================================");
    printf("\n Selamat datang dalam program");
    printf("\n Membaca & menampilkan angka menggunakan array");
    printf("\n Bunga Aprillia (23343030)");
    printf("\n ==============================================");

    printf("\n");

    //clrscr();
    printf("\n Enter the elements of the matrix:\n");
    for (i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++) {
            scanf("%d", &mat[i][j]);
        }
    }

    display(mat);

    return 0;
}

void display(int (*mat)[3]) {
    int i, j;
    printf("\n The elements of the matrix are:\n");
    for (i = 0; i < 3; i++) {
        printf("\n");
        for (j = 0; j < 3; j++)
            printf("\t %d", *(*(mat + i) + j));
    }
}
