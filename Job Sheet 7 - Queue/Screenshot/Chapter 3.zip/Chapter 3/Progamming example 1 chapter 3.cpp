/* Progamming Examples Chapter 3
    Programmmer : Bunga Aprillia
	Nim  		: 23343030
	Mata Kuliah : Struktur Data
    Soal  		: 1. Write a program to read and display n numbers using an array.*/
    
#include <stdio.h>

int main(){
    int i, n, arr[20];
    
    printf("\n \t\t\t ==============================================");
    printf("\n \t\t\t 	Selamat datang dalam program"	);
    printf("\n \t\t\t Membaca & menampilkan angka menggunakan array");
    printf("\n \t\t\t 	Bunga Aprillia (23343030)"	);
    printf("\n \t\t\t ==============================================");
    
    printf("\n");
    
    //clrscr();
    printf("\n Enter the number of elements in the array : ");
    scanf("%d", &n);
    
    // Menggunakan for loop untuk mengisi array
    for(i=0;i<n;i++){
        printf("\n Enter the %dth element : ", i+1);
        scanf("%d", &arr[i]);
    }
    
    printf("\n The array elements are ");
    for(i=0;i<n;i++)
        printf("\t %d", arr[i]);
    
    return 0;
}