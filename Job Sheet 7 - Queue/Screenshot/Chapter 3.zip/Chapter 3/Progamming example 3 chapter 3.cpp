/* Progamming Examples Chapter 3
    Programmmer : Bunga Aprillia
	Nim  		: 23343030
	Mata Kuliah : Struktur Data
    Soal  		: 3. Write a program to print the position of the smallest number of n numbers using arrays*/
    
#include <stdio.h>

int main() {
    int i, n, arr[20], small, pos;

    printf("\n \t\t\t ==============================================");
    printf("\n \t\t\t 	Selamat datang dalam program");
    printf("\n \t\t\t Membaca & menampilkan angka menggunakan array");
    printf("\n \t\t\t 	Bunga Aprillia (23343030)");
    printf("\n \t\t\t ==============================================");

    printf("\n");

    printf("\n Enter the number of elements in the array : ");
    scanf("%d", &n);
    printf("Enter the elements : ");
    for (i = 0; i < n; i++)
        scanf("%d", &arr[i]);
    small = arr[0];
    pos = 0;
    for (i = 1; i < n; i++) {
        if (arr[i] < small) {
            small = arr[i];
            pos = i;
        }
    }
    printf("\n The smallest element is : %d", small);
    printf("\n The position of the smallest element in the array is : %d", pos);
    return 0;
}
