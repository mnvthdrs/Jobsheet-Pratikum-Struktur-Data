/* Progamming Examples Chapter 3
    Programmmer : Bunga Aprillia
	Nim  		: 23343030
	Mata Kuliah : Struktur Data
    Soal  		: 5. Write a program to enter h number of digits. Form a number using these digits.*/
    
#include <stdio.h>
#include <conio.h>
#include <math.h>
int main()
{
	int number=0, digit[10], numofdigits,i;
	
	printf("\n \t\t\t ==============================================");
    printf("\n \t\t\t 	Selamat datang dalam program");
    printf("\n \t\t\t Membaca & menampilkan angka menggunakan array");
    printf("\n \t\t\t 	Bunga Aprillia (23343030)");
    printf("\n \t\t\t ==============================================");

    printf("\n");

	//clrscr();
	printf("\n Enter the number of digits : ");
	scanf("%d", &numofdigits);
	for(i=0;i<numofdigits;i++)
	{
		printf("\n Enter the digit at position %d", i+1);
		scanf("%d", &digit[i]);
	}
	i=0;
	while(i<numofdigits)
	{
		number = number + digit[i] * pow(10,i);
		i++;
	}
	printf("\n The number is : %d", number);
	return 0;
}
