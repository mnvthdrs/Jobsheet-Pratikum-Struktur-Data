/* Progamming Examples Chapter 3
    Programmmer : Bunga Aprillia
	Nim  		: 23343030
	Mata Kuliah : Struktur Data
    Soal  		: 23. Write a program to multiply two m x n matrices.*/
    
#include <stdio.h>

int main() {
    int i, j, k;
    int rows1, cols1, rows2, cols2, res_rows, res_cols;
    int mat1[5][5], mat2[5][5], res[5][5];

    printf("\n ==============================================");
    printf("\n Selamat datang dalam program");
    printf("\n Membaca & menampilkan angka menggunakan array");
    printf("\n Bunga Aprillia (23343030)");
    printf("\n ==============================================");

    printf("\n");

    printf("\n Enter the number of rows in the first matrix : ");
    scanf("%d", &rows1);
    printf("\n Enter the number of columns in the first matrix : ");
    scanf("%d", &cols1);
    printf("\n Enter the number of rows in the second matrix : ");
    scanf("%d", &rows2);
    printf("\n Enter the number of columns in the second matrix : ");
    scanf("%d", &cols2);

    if (cols1 != rows2) {
        printf("\n The number of columns in the first matrix must be equal to the number of rows in the second matrix");
        return 0;
    }

    res_rows = rows1;
    res_cols = cols2;

    printf("\n Enter the elements of the first matrix:\n");
    for (i = 0; i < rows1; i++) {
        for (j = 0; j < cols1; j++) {
            scanf("%d", &mat1[i][j]);
        }
    }

    printf("\n Enter the elements of the second matrix:\n");
    for (i = 0; i < rows2; i++) {
        for (j = 0; j < cols2; j++) {
            scanf("%d", &mat2[i][j]);
        }
    }

    for (i = 0; i < res_rows; i++) {
        for (j = 0; j < res_cols; j++) {
            res[i][j] = 0;
            for (k = 0; k < cols1; k++) {
                res[i][j] += mat1[i][k] * mat2[k][j];
            }
        }
    }

    printf("\n The elements of the product matrix are:\n");
    for (i = 0; i < res_rows; i++) {
        for (j = 0; j < res_cols; j++) {
            printf("\t%d", res[i][j]);
        }
        printf("\n");
    }

    return 0;
}
